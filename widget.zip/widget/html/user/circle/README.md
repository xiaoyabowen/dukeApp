#文件说明


```pre

├── index   // 活动
├── activeDetail   // 活动详情
├── signYesPer   // 已报名
├── allDiscuss   // 全部评论
├── ticket   // 电子票
├── myActives   // 我的活动


├── publishActivity   // 发布活动

├── editActivityDetail   // 发布活动详情

├── manActivity   // 管理活动

├── manPerson   // 人员管理

├── preview   // 活动预览

```
