#文件说明


```pre
组件名字
├── activities   // 活动详情
├── information   // 基本信息
├── sign_suc   // 已报名
├── sign_erro   // 已取消
├── myrelease   // 我的发布
├── myjoin   // 我参加的


```
