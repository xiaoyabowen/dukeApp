#文件说明


```pre

├── editPass   // 修改密码
├── xiugaiPass   // 修改  设置的密码
├── editPhone           // 修改手机号
├── iconPush          // 消息推送设置
├── mine           // 我的
├── setUp             // 设置
├── updateWork             // 上传附件简历
├── WorkReshName             // 附件简历重命名
├── workUp             // 附件简历已上传
├── userCenter             // 个人中心
├── seeResume             // 预览简历
├── sendEmail             // 发送邮箱简历
├── editInfo             // 编辑信息
├── vipCard             // 金卡vip
├── authenCard             // 金卡vip认证
├── Interview             // 面试日程
├── InterviewDetail             // 面试日程详情
├── myOffer             // myOffer  我的录用
├── InterviewStar             // 面试评价
├── Offline             // 职位下线
├── addWork             // 添加工作经历
├── addEdution             // 添加教育经历
├── addProduct             // 添加项目经历
├── addEditWork             // 编辑工作经历
├── personHome             // 我的个人主页
├── homeChoose             //  denglu  选择    千里马 还是   伯乐
├── resume_CompanyLi             //  关联工作经历
├── createPhone             // 创建简历 第一步 绑定手机号
├── Feedback             // 意见反馈
├── aboutDuke             // 关于我们
├── mineAction             // 我的 个人中心  改版  
├── editlnfo_body             // 我的 个人中心 编辑 改版  




```
