#文件说明


```pre

├── editPass   // 修改密码
├── editPhone           // 修改手机号
├── iconPush          // 消息推送设置
├── mine           // 我的
├── setUp             // 设置
├── updateWork             // 上传附件简历
├── WorkReshName             // 附件简历重命名
├── workUp             // 附件简历已上传
├── userCenter             // 个人中心


├── creditCards             // 申请信用卡--列表页
├── creditCard_details             // 信用卡详情页
├── creditCard_apply             // 申请信用卡
├── subscribed_positions             // 订阅的职位
├── my_Concern             // 我的关注
├── setting              // 设置
├── create_resume              // 创建简历
├── resume_level2              // 创建简历二级页面(暂无用)
├── resume_Mailbox              // 输入邮箱号
├── resume_Name              // 姓名
├── resume_Company              // 您的公司名称
├── resume_Department              // 您的所属部门
├── resume_Position              // 您的职位名称
├── resume_Work              // 输入工作内容
├── resume_School              // 输入学校名称
├── resume_Major         // 您的专业名称
├── resume_Project           // 您的项目名称
├── resume_ProjectDescription      // 项目描述
├── resume_Achievement              // 您的成就
├── resume_ProjectLinks            // 项目链接
├── resume_SocialHomepage          // 您的社交主页
├── resume_SocialEditHomepage          // 您的社交主页 编辑
├── resume_BindingPhone          // 绑定手机号
├── resume_imgWorks          // 图片作品（0/50）
├── resume_expectations          // 求职期望
├── resume_positionType          // 选择职位类型
├── resume_CompanyIndustry          // 选择公司行业
├── resume_SkillLabel          // 技能标签
├── resume_Introduce          // 自我描述
├── resume_Comprehensive          // 综合能力
├── resume_editExpectations          // 编辑求职期望
├── resume_editResume          // 编辑在线简历
├── resume_editProject          // 编辑项目经历
├── resume_addProject          // 添加项目经历
├── myDelivery            // 我的投递
├── resume_addWork             // 添加工作经历
├── resume_addEdution            // 添加教育经历
├── resume_editEdution            // 编辑教育经历
├── user_addLink            // 添加链接
├── edit_Subscription            // 修改订阅
├── add_Subscription            // 添加订阅
├── shielding            // 屏蔽公司
├── addShieldCompany            // 添加屏蔽公司

```
