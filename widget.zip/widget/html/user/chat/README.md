#文件说明


```pre

├── index           // 聊天首页
├── chat_Room          // 聊天界面


```
