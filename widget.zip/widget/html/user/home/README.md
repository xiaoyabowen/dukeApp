#文件说明


```pre

├── companyInfo            // 公司详情
├── home           // 首页
├── position          // 职位详情


```
