#文件说明


```pre

├── index           // 巨划算-旅游
├── tripDate           // 巨划算-旅游 -  日历
├── visaApply           // 巨划算-旅游 -  申请签证




```
