#文件说明


```pre

├── index           // 巨划算首页

├── addCards           // 巨划算添加银行卡
├── payment           // 输入支付密码
=======
├── Adress           // 巨划算  地址
├── addAdress           // 巨划算  新增地址
├── confirmOrder           // 巨划算  确认订单




```
