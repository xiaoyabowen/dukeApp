#文件说明


```pre

├── index           // 聊天首页
├── chat_Room          // 聊天界面
├── seeResume          // 查看简历详情
├── add_Subscription          // 我的订阅 添加
├── resume_Company          // 我的订阅  公司名称
├── resume_positionType          // 我的订阅  职位类别
├── resume_CompanyIndustry          // 我的订阅  行业类别
├── subscribed_positions          // 我的订阅  缺省页
├── companyInfoFinsh          // 公司信息完善
├── whriteComInfo          // 填写公司信息
├── whriteComPro          // 填写公司介绍
├── whriteComWelfare          // 填写公司福利
├── whriteComImg          // 填写公司照片
├── whriteComSuggest          // 填写产品介绍
├── whriteComMange          // 填写高管介绍
├── mangePosition          // 职位管理
├── mangePositionDetail          // 职位管理  详情
├── subscribed_positions          // 职位订阅
├── setting          // 设置
├── CandidateCol          // 收藏的  候选人
├── myAccountNumber          // 我的账号
├── setPass          // 设置 密码
├── pushNews          // 消息推送设置
├── phoneBinding          // 绑定手机号



```
