#文件说明


```pre

├── index           // 聊天首页
├── chat_Room          // 聊天界面
├── preliminary          // 初试
├── offer          // 我的录用


```
