#文件说明


```pre


├── index           // 聊天首页
├── chat_Room          // 聊天界面


├── fillInfo          // 填写信息
├── editfillInfo          // 编辑基本信息
├── resume_Mailbox          // 编辑邮箱
├── resume_Name          // 编辑姓名
├── resume_fillComName          // b编辑公司名称
├── companyAuthen          // 企业邮箱认证
├── companyAuthenYZ          // 企业验证码认证
├── companyEmailAuthen          // 企业认证
├── uploadLicense          // 上传营业执照
├── inAuthen          // 认证中
├── postsPublish          // 发布职位
├── resume_positionType          // z职位名称
├── resume_SkillLabel          // 技能标签
├── companyAdress          // 工作地址



```
