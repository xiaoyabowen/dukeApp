
function yesPayInit(Vue) {
    var str = dataValue('user/comment/yesPay.html')



    return {
        template: str,
        data: function() {
            return {

            }
        },
        created: function() {

        },
        mounted :function (){


        },

        methods: {

        }
    }
}
