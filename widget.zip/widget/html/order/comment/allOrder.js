
function allOrderInit(Vue) {
    var str = dataValue('order/comment/allOrder.html')



    return {
        template: str,
        data: function() {
            return {

            }
        },
        created: function() {

        },
        mounted :function (){


        },

        methods: {

        }
    }
}
