
function waitPayInit(Vue) {
    var str = dataValue('user/comment/waitPay.html')



    return {
        template: str,
        data: function() {
            return {

            }
        },
        created: function() {

        },
        mounted :function (){


        },

        methods: {

        }
    }
}
